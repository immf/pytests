const widget = document.getElementById('chatbot-widget');
const icon = document.getElementById('chatbot-icon');
const input = document.getElementById('chat-input');
const body = document.getElementById('chat-body');

icon.addEventListener('click', () => {
  widget.classList.toggle('hidden');
});

input.addEventListener('keypress', async (e) => {
  if (e.key === 'Enter' && input.value.trim()) {
    const userMsg = input.value;
    input.value = '';
    appendMessage('Você', userMsg);

    const botReply = await getBotReply(userMsg);
    appendMessage('Bot', botReply);
  }
});

function appendMessage(sender, msg) {
  const msgDiv = document.createElement('div');
  msgDiv.innerHTML = `<strong>${sender}:</strong> ${msg}`;
  body.appendChild(msgDiv);
  body.scrollTop = body.scrollHeight;
}

async function getBotReply(message) {
  try {
    const response = await fetch('http://localhost:5000/chat', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ message })
    });

    const data = await response.json();
    return data.reply || 'Erro ao obter resposta.';
  } catch (error) {
    console.error(error);
    return 'Erro ao conectar com o servidor.';
  }
}

setTimeout(() => {
  widget.classList.remove('hidden');
}, 3000);
