
import os
from dotenv import load_dotenv
import openai
import numpy as np

load_dotenv()
client = openai.OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

def gerar_embedding(texto):
    response = client.embeddings.create(
        model="text-embedding-3-small",
        input=texto
    )
    return response.data[0].embedding

def cosine_similarity(v1, v2):
    v1 = np.array(v1)
    v2 = np.array(v2)
    return np.dot(v1, v2) / (np.linalg.norm(v1) * np.linalg.norm(v2))

def carregar_base_faq(path="faq_base_conhecimento.txt"):
    base = []
    with open(path, "r", encoding="utf-8") as f:
        blocos = f.read().strip().split("\n\n")
        for bloco in blocos:
            linhas = bloco.strip().split("\n")
            if len(linhas) == 2:
                pergunta = linhas[0].replace("Pergunta: ", "").strip()
                resposta = linhas[1].replace("Resposta: ", "").strip()
                embedding = gerar_embedding(pergunta)
                base.append({"pergunta": pergunta, "resposta": resposta, "embedding": embedding})
    return base

def buscar_resposta_similar(pergunta_usuario, base):
    embedding_user = gerar_embedding(pergunta_usuario)
    melhor_score = -1
    melhor_resposta = "Desculpe, não consegui encontrar uma resposta para isso."
    for item in base:
        score = cosine_similarity(embedding_user, item["embedding"])
        if score > melhor_score:
            melhor_score = score
            melhor_resposta = item["resposta"]
    return melhor_resposta, melhor_score
